library(testthat)
library(ugametrics)

test_check("ugametrics")
